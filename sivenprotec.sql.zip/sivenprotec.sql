-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 30-03-2022 a las 22:27:31
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sivenprotec`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `documento` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `telefono` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `documento`, `nombre`, `telefono`, `correo`, `direccion`, `fecha`) VALUES
(1, '123', 'Maria Lopez', '3036472836', 'maria@correo.com', 'Antioquia', '2022-03-10 14:12:50'),
(2, '456', 'Lorena Casas', '3062783913', 'lorena_casas@correo.com', 'Bogota', '2022-03-30 14:59:59'),
(3, '789', 'Matias Soto', '3082963718', 'matias123@correo.com', 'Rionegro, Antioquia', '2022-03-30 15:00:50');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nit` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `telefono` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`id`, `nombre`, `nit`, `telefono`, `direccion`) VALUES
(1, 'SIVENPROTEC', '21316251321', '30253728192', 'Antioquia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle`
--

CREATE TABLE `detalle` (
  `id` int(11) NOT NULL,
  `codigoProducto` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio` decimal(10,0) NOT NULL,
  `idVenta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `detalle`
--

INSERT INTO `detalle` (`id`, `codigoProducto`, `cantidad`, `precio`, `idVenta`) VALUES
(1, '345', 6, '500', 1),
(2, '345', 3, '500', 2),
(3, '345', 2, '500', 3),
(4, '345', 1, '500', 4),
(5, '345', 1, '500', 5),
(6, '345', 1, '500', 6),
(7, '345', 1, '500', 7),
(8, '345', 1, '500', 8),
(9, '345', 1, '500', 9),
(10, '345', 1, '500', 10),
(11, '345', 1, '500', 11),
(12, '345', 2, '500', 11),
(13, '123', 3, '200', 11),
(14, '123', 5, '200', 11),
(15, '345', 5, '500', 11),
(16, '345', 2, '500', 12),
(17, '123', 5, '200', 12),
(18, '345', 2, '500', 13),
(19, '123', 1, '200', 13),
(20, '345', 5, '2500', 14),
(21, '123', 1, '200', 14),
(22, '345', 5, '2500', 15),
(23, '123', 2, '400', 15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `codigoProducto` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `cantidad` varchar(20) COLLATE utf8mb4_spanish_ci NOT NULL,
  `precioVenta` decimal(50,0) NOT NULL,
  `precioCompra` decimal(50,0) NOT NULL,
  `proveedor` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `codigoProducto`, `nombre`, `cantidad`, `precioVenta`, `precioCompra`, `proveedor`, `fecha`) VALUES
(1, '345', 'Impresora HP', '79', '500', '120', 'José Rodriguez', '2022-03-10 14:14:41'),
(2, '123', 'Microfono Logitech', '33', '200', '130', 'José Rodriguez', '2022-03-17 00:16:17'),
(3, '876', 'Camara Canon', '50', '230', '180', 'Emiliano Garcia', '2022-03-30 15:19:59'),
(4, '498', 'Portatil Asus', '30', '100', '40', 'Eferson Gómez', '2022-03-30 15:26:45');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id` int(11) NOT NULL,
  `documento` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `telefono` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `codigoProducto` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id`, `documento`, `nombre`, `direccion`, `telefono`, `codigoProducto`, `fecha`) VALUES
(1, '1234', 'José Rodriguez', 'Bogotá', '302645387', '345', '2022-03-10 14:13:22'),
(2, '376', 'Emiliano Garcia', 'Marinilla', '3025648734', '876', '2022-03-30 15:06:25'),
(3, '862', 'Eferson Gómez', 'Rionegro', '3136528472', '498', '2022-03-30 15:06:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `correo` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL,
  `contrasena` varchar(100) COLLATE utf8mb4_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contrasena`) VALUES
(1, 'maria', 'maria@correo.com', '123'),
(2, 'lucia', 'lucia@correo.com', '123'),
(3, 'Melissa Zapata', 'melissa.zapata@correo.com', 'programa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id` int(11) NOT NULL,
  `cliente` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `vendedor` varchar(50) COLLATE utf8mb4_spanish_ci NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id`, `cliente`, `vendedor`, `total`, `fecha`) VALUES
(1, 'maria', 'SIVENPROTEC', '3000.00', '2022-03-10 14:15:09'),
(2, 'maria', 'SIVENPROTEC', '1500.00', '2022-03-10 14:21:00'),
(3, 'maria', 'SIVENPROTEC', '1000.00', '2022-03-10 14:24:49'),
(4, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 14:59:41'),
(5, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 14:59:55'),
(6, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 15:00:56'),
(7, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 15:06:40'),
(8, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 15:08:21'),
(9, 'maria', 'SIVENPROTEC', '500.00', '2022-03-10 15:09:28'),
(10, 'maria', 'SIVENPROTEC', '500.00', '2022-03-11 16:31:31'),
(11, 'maria', 'SIVENPROTEC', '500.00', '2022-03-11 17:50:56'),
(12, 'maria', 'SIVENPROTEC', '2000.00', '2022-03-18 13:07:32'),
(13, 'maria', 'SIVENPROTEC', '1200.00', '2022-03-18 13:12:00'),
(14, 'maria', 'SIVENPROTEC', '2700.00', '2022-03-18 14:44:48'),
(15, 'maria', 'SIVENPROTEC', '2900.00', '2022-03-30 14:47:04');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle`
--
ALTER TABLE `detalle`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `ventas`
--
ALTER TABLE `ventas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `detalle`
--
ALTER TABLE `detalle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ventas`
--
ALTER TABLE `ventas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
